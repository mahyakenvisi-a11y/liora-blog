+++
draft = false
date = 2023-01-04T23:21:06+01:00
title = "sintaxe"
url = "categoria/sintaxe"
+++
