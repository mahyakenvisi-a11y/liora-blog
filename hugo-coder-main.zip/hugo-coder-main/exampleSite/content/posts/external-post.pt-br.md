+++
authors = ["Programador Solitário"]
date = "2023-07-06"
title = "Página Externa: Wiki Hugo Coder"
slug = "hugo-coder-wiki"
tags = [
    "hugo"
]
externalLink = "https://github.com/luizdepra/hugo-coder/wiki"
+++
