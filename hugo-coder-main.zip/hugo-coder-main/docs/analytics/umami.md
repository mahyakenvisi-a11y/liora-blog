# Umami

```toml
[params.umami]
    siteID = "ABCDE"
    scriptURL = "analytics.REGION.umami.is/SCRIPTNAME.js" 
    # refer to the "tracking code" tab in your umami website dashboard 
    # to obtain the script url
```
