# Fathom Analytics

```toml
[params.fathomAnalytics]
  siteID = "ABCDE"
  serverURL = "cdn.usefathom.com" # (optional) Replace if you use a custom domain
```