# Vercel Analytics

```toml
[params]
    vercelAnalytics = true
```
