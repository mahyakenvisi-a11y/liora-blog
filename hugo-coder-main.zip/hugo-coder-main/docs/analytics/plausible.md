# Plausible Analytics

```toml
[params.plausibleAnalytics]
  domain = "example.com"
  serverURL = "plausible.io" # (optional) Replace if you use a custom domain
```
