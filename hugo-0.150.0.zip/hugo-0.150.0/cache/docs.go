// Package cache contains the different cache implementations.
package cache
