---
name: Proposal
about: Propose a new feature for Hugo
title: ''
labels: 'Proposal, NeedsTriage'
assignees: ''

---


<!-- Describe this new feature. Think about if it really belongs in the Hugo core module; you may want to discuss it on https://discourse.gohugo.io/ first.  -->