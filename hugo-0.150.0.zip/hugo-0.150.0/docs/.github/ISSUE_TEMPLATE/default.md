---
name: Default
about: This is the default issue template.
labels:
  - NeedsTriage
---
