See [content/LICENSE.md](content/LICENSE.md) for the license of the content of this repository.

The theme (layouts, CSS, JavaScript etc.) of this repository has no open source license. It is custom made for the Hugo sites and is not meant for reuse.
