---
title: Contribute to the Hugo project
linkTitle: Contribute
description: Contribute to development, documentation, and themes.
categories: []
keywords: []
weight: 10
aliases: [/tutorials/how-to-contribute-to-hugo/,/community/contributing/]
---
