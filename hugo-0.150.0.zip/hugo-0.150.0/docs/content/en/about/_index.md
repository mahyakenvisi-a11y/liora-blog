---
title: About Hugo
linkTitle: About
description: Learn about Hugo and its features, privacy protections, and security model.
categories: []
keywords: []
weight: 10
aliases: [/about-hugo/,/docs/]
---
