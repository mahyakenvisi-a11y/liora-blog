---
title: Global functions
linkTitle: global
description: Use these global functions to access page and site data.
categories: []
---
