---
title: Data functions
linkTitle: data
description: Use these functions to read local or remote data files.
categories: []
keywords: []
---
