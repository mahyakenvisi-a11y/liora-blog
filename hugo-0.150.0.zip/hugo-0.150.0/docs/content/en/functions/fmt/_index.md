---
title: Fmt functions
linkTitle: fmt 
description: Use these functions to print strings within a template or to print messages to the terminal.
categories: []
keywords: []
---
