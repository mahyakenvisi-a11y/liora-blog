---
title: Compare functions
linkTitle: compare
description: Use these functions to compare two or more values.
categories: []
keywords: []
---
