---
title: Encoding functions
linkTitle: encoding
description: Use these functions to encode and decode data.
categories: []
keywords: []
---
