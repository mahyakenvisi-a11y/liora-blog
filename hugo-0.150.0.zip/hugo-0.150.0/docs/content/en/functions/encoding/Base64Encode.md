---
title: encoding.Base64Encode
description: Returns the base64 decoding of the given content.
categories: []
keywords: []
params:
  functions_and_methods:
    aliases: [base64Encode]
    returnType: string
    signatures: [encoding.Base64Encode INPUT]
aliases: [/functions/base64, /functions/base64Encode]
---

```go-html-template
{{ "Hugo" | base64Encode }} → SHVnbw==
```
