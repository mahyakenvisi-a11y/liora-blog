---
title: Cast functions
linkTitle: cast
description: Use these functions to cast a value from one data type to another.
categories: []
keywords: []
---
