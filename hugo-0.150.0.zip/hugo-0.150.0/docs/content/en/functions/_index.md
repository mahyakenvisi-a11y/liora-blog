---
title: Functions
description: Use these functions within your templates and archetypes.
categories: []
keywords: []
weight: 10
aliases: [/layout/functions/,/templates/functions]
---
