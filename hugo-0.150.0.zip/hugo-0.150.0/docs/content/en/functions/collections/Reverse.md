---
title: collections.Reverse
description: Reverses the order of a collection.
categories: []
keywords: []
params:
  functions_and_methods:
    aliases: []
    returnType: any
    signatures: [collections.Reverse COLLECTION]
aliases: [/functions/collections.reverse]
---

```go-html-template
{{ slice 2 1 3 | collections.Reverse }} → [3 1 2]
```
