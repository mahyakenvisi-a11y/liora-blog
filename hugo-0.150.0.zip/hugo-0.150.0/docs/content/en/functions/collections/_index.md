---
title: Collections functions
linkTitle: collections
description: Use these functions to work with arrays, slices, maps, and page collections.
categories: []
keywords: []
---
