---
title: Command line interface
linkTitle: CLI
description: Use the command line interface (CLI) to manage your site.
categories: []
keywords: []
weight: 10
---
