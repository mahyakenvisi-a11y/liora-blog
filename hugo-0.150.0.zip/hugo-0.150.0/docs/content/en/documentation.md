---
title: Hugo Documentation
linkTitle: Docs
description: Hugo is the world's fastest static website engine. It's written in Go (aka Golang) and developed by bep, spf13 and friends.
layout: list
params:
  searchable: false
---

<!--
If we want content on this page at some point, considering taking it from:

- https://gohugo.io/about/introduction/
- https://gohugo.io/about/features/

Try to use the same language (e.g., tagline) everywhere:

- Home: https://gohugo.io/
- Docs: https://gohugo.io/documentation/
- Project repo: https://github.com/gohugoio/hugo?tab=readme-ov-file#readme
- Docs repo: https://github.com/gohugoio/hugoDocs?tab=readme-ov-file#readme 
-->
