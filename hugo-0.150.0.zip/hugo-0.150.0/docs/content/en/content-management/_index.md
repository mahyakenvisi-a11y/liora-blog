---
title: Content management
description: Hugo makes managing large static sites easy with support for archetypes, content types, menus, cross references, summaries, and more.
categories: []
keywords: []
weight: 10
aliases: [/content/,/content/organization]
---
