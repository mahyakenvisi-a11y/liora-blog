---
_comment: Do not remove front matter.
---

path
: (`string`) The path to the target page. Paths without a leading slash (`/`) are resolved first relative to the current page, and then relative to the rest of the site.

lang
: (`string`) The language of the target page. Default is the current language. Optional.

outputFormat
: (`string`) The output format of the target page. Default is the current output format. Optional.
