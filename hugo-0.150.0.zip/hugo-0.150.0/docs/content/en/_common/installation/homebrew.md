---
_comment: Do not remove front matter.
---

### Homebrew

[Homebrew] is a free and open-source package manager for macOS and Linux. To install the extended edition of Hugo:

```sh
brew install hugo
```

[Homebrew]: https://brew.sh/
