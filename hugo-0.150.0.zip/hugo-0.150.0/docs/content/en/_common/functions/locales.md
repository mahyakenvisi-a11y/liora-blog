---
_comment: Do not remove front matter.
---

> [!note]
> Localization of dates, currencies, numbers, and percentages is performed by the [gohugoio/locales] package. The language tag of the current site must match one of the listed locales.

[gohugoio/locales]: https://github.com/gohugoio/locales
