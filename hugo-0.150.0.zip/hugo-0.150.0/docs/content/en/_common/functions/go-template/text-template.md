---
_comment: Do not remove front matter.
---

See Go's [text/template] documentation for more information.

[text/template]: https://pkg.go.dev/text/template
