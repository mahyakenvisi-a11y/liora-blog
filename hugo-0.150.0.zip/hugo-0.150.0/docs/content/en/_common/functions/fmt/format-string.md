---
_comment: Do not remove front matter.
---

The documentation for Go's [fmt] package describes the structure and content of the format string.

[fmt]: https://pkg.go.dev/fmt
