---
_comment: Do not remove front matter.
---

> [!note]
> Use this method with [global resources](g), [page resources](g), or [remote resources](g).
