---
title: Configure minify
linkTitle: Minify
description: Configure minify.
categories: []
keywords: []
---

This is the default configuration:

{{< code-toggle config=minify />}}

See the [tdewolff/minify] project page for details.

[tdewolff/minify]: https://github.com/tdewolff/minify
