<a href="https://gohugo.io/"><img src="https://raw.githubusercontent.com/gohugoio/gohugoioTheme/master/static/images/hugo-logo-wide.svg?sanitize=true" alt="Hugo" width="565"></a>

A fast and flexible static site generator built with love by [bep], [spf13], and [friends] in [Go].

---

[![Netlify Status](https://api.netlify.com/api/v1/badges/e0dbbfc7-34f1-4393-a679-c16e80162705/deploy-status)](https://app.netlify.com/sites/gohugoio/deploys)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://gohugo.io/contribute/documentation/)

This is the repository for the [Hugo](https://github.com/gohugoio/hugo) documentation site.

Please see the [contributing] section for guidelines, examples, and process.

[bep]: https://github.com/bep
[spf13]: https://github.com/spf13
[friends]: https://github.com/gohugoio/hugo/graphs/contributors
[go]: https://go.dev/
[contributing]: https://gohugo.io/contribute/documentation

# Install

```sh
npm i
hugo server
```

**Note:** We're working on removing the need to run `npm i` for local development. Stay tuned.
